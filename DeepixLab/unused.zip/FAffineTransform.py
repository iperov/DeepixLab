from __future__ import annotations

import math
from functools import cached_property

from ..collections import FDict
from .FAffineMat import FAffineMat
from .FVec2 import FVec2


class FAffineTransform:
    """
    Immutable 2D transformation (Scaled-rotated space shifted by pos) described as parameters.
    """
    
    @staticmethod
    def from_state(state : FDict) -> FAffineTransform:
        return FAffineTransform(pos=FVec2.from_state( state.get('pos', FDict()) ),
                                scale=FVec2.from_state( state.get('scale', FDict()) ),
                                rotation=state.get('rotation', 0),
                                )
    
    @staticmethod
    def from_mat(mat : FAffineMat) -> FAffineTransform:
        """decompose transform parameters from FAffineMat"""
        A11, A12, pos_x, \
        A21, A22, pos_y = mat._values
        
        a = math.atan2(A21,A11)
        
        sin_a = math.sin(a)
        cos_a = math.cos(a)
        
        msy = A12*cos_a+A22*sin_a
                
        sx = math.sqrt(A11**2+A21**2)
        if sin_a != 0:
            sy = (msy*cos_a - A12) / sin_a            
        else:
            sy = (A22 - msy*sin_a) / cos_a
            
        #shear = msy / sy
        return FAffineTransform(pos=FVec2(pos_x, pos_y),
                                scale=FVec2(sx, sy),
                                rotation=a)
        
    def __init__(self, pos : FVec2 = FVec2(0,0), scale : FVec2 = FVec2(1,1), rotation : float = None, rotation_deg : float = None):
        self._pos = pos
        self._scale = scale
        
        if rotation is not None and rotation_deg is not None:
            raise ValueError('should be set either rotation or rotation_deg')
        elif rotation_deg is not None:
            rotation = rotation_deg*math.pi/180
        elif rotation is None:
            rotation = 0
            
        self._rotation = rotation
            
    @property
    def pos(self) -> FVec2: return self._pos
    @property
    def scale(self) -> FVec2: return self._scale
    @property
    def rotation(self) -> float: return self._rotation
    @cached_property
    def rotation_deg(self) -> float: return self._rotation * 180 / math.pi
    
    def get_state(self) -> FDict:
        return FDict({'pos' : self._pos.get_state(),
                      'scale' : self._scale.get_state(),
                      'rotation' : self._rotation})
    
    def set_pos(self, pos : FVec2) -> FAffineTransform:             return FAffineTransform(pos, self._scale, self._rotation)
    def set_scale(self, scale : FVec2) -> FAffineTransform:         return FAffineTransform(self._pos, scale, self._rotation)
    def set_rotation(self, rotation : float) -> FAffineTransform:   return FAffineTransform(self._pos, self._scale, rotation)
    def set_rotation_deg(self, rotation_deg : float) -> FAffineTransform: return self.set_rotation(rotation_deg * math.pi / 180)
    
    # @overload
    # def translate(self, delta : FVec2) -> FAffineTransform:
    #     """change position by `delta`"""
    # @overload
    # def translate(self, x : float, y : float) -> FAffineTransform:
    #     """change position by `x`,`y`"""
    # def translate(self, *args) -> FAffineTransform: return self.set_pos(self._pos + FVec2(*args))
    # def rotate(self, rad : float) -> FAffineTransform: return self.set_rotation(self._rotation+rad)
    # def rotate_deg(self, deg : float) -> FAffineTransform: return self.set_rotation_deg(self.rotation_deg+deg)
    
    @cached_property
    def mat(self) -> FAffineMat:
        """return mat for transform FAffineTransform space to origin as scale->rotate->translate"""
        pos = self._pos
        s = self._scale
        r = self._rotation
        cr = math.cos(r)
        sr = math.sin(r)
        return FAffineMat( (s.x*cr,   -sr, pos.x,
                             sr ,  s.y*cr, pos.y) )
    
    def __hash__(self) -> int: return hash((self._pos, self._scale, self._rotation))
    def __eq__(self, other) -> bool:
        if self is other:
            return True
        if isinstance(other, FAffineTransform):
            return (self._pos == other._pos) & (self._scale == other._scale) & (self._rotation == other._rotation)
        return False
    
    def __repr__(self): return self.__str__()
    def __str__(self): return f"P:{self._pos} S:{self._scale} R:{self.rotation_deg}"
        