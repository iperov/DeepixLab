from typing import Any, Callable

from .. import mx, qt
from .QComboBox import QComboBox


class QComboBoxMxMultiChoice(QComboBox):
    def __init__(self,  mc : mx.IMultiChoice_v,
                        stringifier : Callable[ [Any], str ] = None,
                        **kwargs):
        super().__init__(**kwargs)
        self._mc = mc
        self._sc_avail = None
        
        qc = self.q_combobox
        view = qt.QListView(qc)
        qc.setView(view)
        
        view.pressed.connect(self._on_view_item_pressed)
        
        model = qt.QStandardItemModel(qc)
        
        qc.setModel(model)
        
        item = qt.QStandardItem('qwe')
        item.setCheckable(True)
        
        model.appendRow(item)
        
        item = qt.QStandardItem('asd')
        item.setCheckable(True)
        
        model.appendRow(item)
        
    def _on_view_item_pressed(self, index):
        print(index)
        qc = self.q_combobox
        model : qt.QStandardItemModel = qc.model()
        
        item = model.itemFromIndex(index)
        
        if item.checkState() == qt.Qt.CheckState.Checked:
            item.setCheckState(qt.Qt.CheckState.Unchecked)
        else:
            item.setCheckState(qt.Qt.CheckState.Checked)
        
        # self.add_item("A")
        # self.add_item("B")
        # self.add_item("C")
        # qc.setEditable(True)
        # qc.lineEdit().setReadOnly(True)
        # qc.view().setSelectionMode(qt.QAbstractItemView.SelectionMode.MultiSelection)
        
    # def add_item(self, text : str, data : Any = None):
    #     super().add_item(text, data=data)
    #     qc = self.q_combobox
    #     idx = self.q_combobox.count()-1
        
    #     model = qc.model()
    #     #x = qc.model().itemData(idx)
        
    #     qt.QModelIndex
        
    #     import code
    #     code.interact(local=dict(globals(), **locals()))

        
    # def show_popup(self):
    #     super().show_popup()
    #     qc = self.q_combobox
        
        
        # if stringifier is None:
        #     stringifier = lambda val: '' if val is None else str(val)
        # self._stringifier = stringifier

        # self._conn = self.mx_current_index.listen(lambda idx: self._sc.set(self._sc_avail[idx]))
        # sc.reflect(lambda _: self.update_items()).dispose_with(self)

    # def update_items(self):
    #     avail = self._sc_avail = self._sc.avail
    #     value = self._sc.get()

    #     with self._conn.disabled_scope():
    #         self.clear()
    #         try:
    #             idx = avail.index(value)
    #         except:
    #             idx = None

    #         for x in avail:
    #             self.add_item(self._stringifier(x))

    #         if idx is not None:
    #             self.set_current_index(idx)

    # def show_popup(self) -> None:
    #     self.update_items()
    #     super().show_popup()
