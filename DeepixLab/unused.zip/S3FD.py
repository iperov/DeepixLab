from pathlib import Path
from typing import List

import numpy as np

from core.lib import math as lib_math
from core.lib.math import Rect
from core.lib import onnxruntime as lib_ort
from core.lib.image import FImage

#from xlib.file import SplittedFile

class S3FD:

    @staticmethod
    def get_available_devices() -> List[lib_ort.DeviceRef]:
        return [lib_ort.get_cpu_device()] + lib_ort.get_avail_gpu_devices()

    def __init__(self, device : lib_ort.DeviceRef ):
        if device not in S3FD.get_available_devices():
            raise Exception(f'device {device} is not in available devices for S3FD')

        path = Path(__file__).parent / 'S3FD.onnx' 
        #SplittedFile.merge(path, delete_parts=False)

        self._sess = sess = lib_ort.InferenceSession_with_device(str(path), device)
        self._input_name = sess.get_inputs()[0].name

    def extract(self, img : FImage,
                      resolution : int = None,
                      augment_pyramid=False,
                      augment_hv_flips=False,
                      threshold : float = 0.95,
                      nms_threshold=0.3,
                      min_face_size=8,
                      ) -> List[Rect]:
        """
        arguments

            img    FImage

            min_face_size(8)

            resolution(None) int    scale img by largest side(W or H) to desired size for detection.
                                    Pros: decrease detection time if image is very large, for example 4k
                                          avoid delay if image sequence has different sizes
                                    Cons: loose accuracy of detected rectangles

            augment_pyramid(False) bool     augment by pyramid. Increases faces detected (even false positives), decreases performance.

            augment_hv_flips(False) bool    augment by H/V flips. Increases faces detected (even false positives), decreases performance.
        """
        img = img.bgr().u8().f32(convert=False).apply( lambda img: img - np.float32([104,117,123]))

        H, W, _ = img.shape

        scale = 1.0
        if resolution is not None:
            WH = max(W,H)
            if WH != resolution:
                scale = resolution / WH
                min_face_size *= scale

        if scale != 1.0:
            img = img.resize(int(W*scale), int(H*scale))

        imgs : List[FImage] = [ (img.pad_to_next_divisor(32, 32), scale, False, False) ]

        if augment_pyramid:
            for n in range(1, 5):
                scale = (0.66**n)
                imgs.append( (img.resize(int(W*scale), int(H*scale)).pad_to_next_divisor(32, 32), scale, False, False) )

        if augment_hv_flips:
            add_imgs = []
            for img, scale, _, _ in imgs:

                add_imgs.append( (x := img.h_flip(), scale, True, False) )
                add_imgs.append( (img.v_flip(), scale, False, True) )
                add_imgs.append( (x.v_flip(), scale, True, True) )
            imgs += add_imgs

        preds = []
        for img, scale, flipped_hor, flipped_ver in imgs:
            pred = self._get_preds(img.CHW()[None,...], threshold)
            pred[:,0:4] *= 1/scale
            if flipped_hor:
                pred[:,0] = W - pred[:,0]
            if flipped_ver:
                pred[:,1] = H - pred[:,1]
            preds.append(pred)

        preds = np.concatenate(preds, 0)
        #preds = preds[preds[...,4] >= threshold]

        x,y,w,h,score = preds.T

        l, t, r, b = x-w/2, y-h/2, x+w/2, y+h/2
        keep = lib_math.nms(l,t,r,b, score, nms_threshold)
        l, t, r, b = l[keep], t[keep], r[keep], b[keep]

        faces = []
        for l,t,r,b in np.stack([l, t, r, b], -1):
            if min(r-l,b-t) < min_face_size:
                continue
            faces.append( Rect.from_ltrb(l,t,r,b) )

        return faces





    def _get_preds(self, img : np.ndarray, threshold):
        t = self._sess.run(None, {self._input_name: img})

        preds = []
        variances = [0.1, 0.2]
        for i in range(len(t) // 2):
            ocls, oreg = t[i * 2][0], t[i * 2 + 1][0]
            
            

            stride = 2**(i + 2)    # 4,8,16,32,64,128
            for hindex, windex in [*zip(*np.where(ocls[1, :, :] > threshold))]:
                axc, ayc = stride / 2 + windex * stride, stride / 2 + hindex * stride
                score = ocls[1, hindex, windex]
                loc = np.ascontiguousarray(oreg[:, hindex, windex]).reshape((1, 4))
                priors = np.array([[axc, ayc, stride * 4, stride * 4]])
                bbox = np.concatenate((priors[:, :2] + loc[:, :2] * variances[0] * priors[:, 2:],
                                       priors[:, 2:] * np.exp(loc[:, 2:] * variances[1])), 1)
                bbox[:, :2] -= bbox[:, 2:] / 2
                x, y, w, h = bbox[0]
                preds.append([x, y, w, h, score])

        if len(preds) != 0:
            preds = np.array(preds)

        return preds
