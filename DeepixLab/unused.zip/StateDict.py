from __future__ import annotations

from collections import deque
from pathlib import Path
from types import NoneType

import numpy as np

from core.lib import path as lib_path


class StateDict:
    """
    """
    def __init__(self, d : dict):
        self.__dict = d

    
    def pack(self, rel_path : Path = None) -> dict:
        return StateDict._pack_check_value(self.__dict, rel_path=rel_path)
        
    def unpack(self, rel_path : Path = None) -> dict:
        return StateDict._unpack_check_value(self.__dict, rel_path=rel_path)
            
    @staticmethod
    def _pack_check_value(value, **kwargs):
        """raise on error"""
        value_type = type(value)

        if value_type in (list, deque, tuple, set):
            value = value_type(StateDict._pack_check_value(v, **kwargs) for v in value)
        elif isinstance(value, dict):
            value = { k : StateDict._pack_check_value(v, **kwargs)
                      for k, v in value.items() if StateDict._check_key(k) }
        elif isinstance(value, Path):
            if (rel_path := kwargs.get('rel_path', None)) is not None:
                value = lib_path.relpath(value, rel_path)
        elif not (value_type in (NoneType, int, float, bool, str, bytes, bytearray) \
                or isinstance(value, (np.ndarray, np.generic)) ):
            raise ValueError(f'Type of value {value_type} is not allowed in StateDict.')

        return value
    
    @staticmethod
    def _unpack_check_value(value, **kwargs):
        """raise on error"""
        value_type = type(value)

        if value_type in (list, deque, tuple, set):
            value = value_type(StateDict._unpack_check_value(v, **kwargs) for v in value)
        elif isinstance(value, dict):
            value = { k : StateDict._unpack_check_value(v, **kwargs)
                      for k, v in value.items() if StateDict._check_key(k) }
        elif isinstance(value, Path):
            if (rel_path := kwargs.get('rel_path', None)) is not None:
                value = lib_path.abspath(value, rel_path)
        elif not (value_type in (NoneType, int, float, bool, str, bytes, bytearray) \
                  or isinstance(value, (np.ndarray, np.generic)) ):
            raise ValueError(f'Type of value {value_type} is not allowed in StateDict.')

        return value
    
    @staticmethod
    def _check_key(key):
        if type(key) in (int, float, str, bool):
            return True
        raise ValueError('Key must be a type of (int, float, str, bool)')
    
# class StateDict:
#     """
#     StateDict is a dict-like object that allows only basic python types and numpy types.

#     Path values can be changed using relative path while dumping.
#     """

#     @staticmethod
#     def from_dump( d : dict, rel_path : Path = None) -> StateDict:
#         """
#         create from .dump()'ed dict

#             rel_path    Path values will be unpacked using rel_path.

#         raise on error
#         """
#         return StateDict( dict=StateDict._unpack_check_value(d, rel_path=rel_path), )

#     @staticmethod
#     def create(d : dict = None) -> StateDict:
#         """create from dict or empty"""
#         if d is None:
#             d = {}
#         else:
#             StateDict._check_value(d)
#         return StateDict(dict=d)

#     def __init__(self, **kwargs):
#         if len(kwargs) == 0:
#             raise Exception('use StateDict .create|.from_ methods.')

#         self.__version = kwargs.get('version', 0)
#         self.__dict = kwargs['dict']

#     @property
#     def version(self) -> int:
#         """"""
#         version = self.__version
#         if type(version) == StateDict:
#             version = version.version
#         return version

#     def dump(self, rel_path : Path = None) -> dict:
#         """Returns a copy of internal dict

#             rel_path
#         """
#         return StateDict._dump_check_value(self.__dict, rel_path=rel_path)

#     def get(self, key, default): return self.__dict.get(key, default)

#     def get_sub_state(self, key) -> StateDict:
#         """
#         """
#         StateDict._check_key(key)

#         sub_d = self.__dict.get(key, None)

#         if sub_d is None:
#             sub_d = self.__dict[key] = {}
#         elif not isinstance(sub_d, dict):
#             raise Exception(f'Key {key} has non dict-like value.')

#         return StateDict(dict=sub_d, version=self)

#     def set(self, key, value):
#         StateDict._check_key(key)
#         StateDict._check_value(value)

#         changed = True

#         if key in self.__dict:
#             try:
#                 changed = not StateDict._eq_value(self.__dict[key], value)
#             except:
#                 pass

#         if changed:
#             self.__dict[key] = value

#             if type(self.__version) is StateDict:
#                 self.__version.__version += 1
#             else:
#                 self.__version += 1

#     def __getitem__(self, key): return self.__dict[key]
#     def __setitem__(self, key, value) -> None: self.set(key, value)

#     @staticmethod
#     def _check_value(value):
#         """
#         raise on error
#         """
#         value_type = type(value)

#         if value_type in (list, deque, tuple, set):
#             for v in value:
#                 StateDict._check_value(v)
#         elif isinstance(value, dict):
#             for k, v in value.items():
#                 StateDict._check_key(k)
#                 StateDict._check_value(v)
#         elif not (value_type in (NoneType, int, float, bool, str, bytes, bytearray) \
#                   or isinstance(value, (Path, np.ndarray, np.generic)) ):
#             raise ValueError(f'Type of value {value_type} is not allowed in StateDict.')

#     @staticmethod
#     def _dump_check_value(value, **kwargs):
#         """raise on error"""
#         value_type = type(value)

#         if value_type in (list, deque, tuple, set):
#             value = value_type(StateDict._dump_check_value(v, **kwargs) for v in value)
#         elif isinstance(value, dict):
#             value = { k : StateDict._dump_check_value(v, **kwargs)
#                       for k, v in value.items() if StateDict._check_key(k) }
#         elif isinstance(value, Path):
#             if (rel_path := kwargs.get('rel_path', None)) is not None:
#                 value = lib_path.relpath(value, rel_path)
#         elif not (value_type in (NoneType, int, float, bool, str, bytes, bytearray) \
#                 or isinstance(value, (np.ndarray, np.generic)) ):
#             raise ValueError(f'Type of value {value_type} is not allowed in StateDict.')

#         return value

#     @staticmethod
#     def _unpack_check_value(value, **kwargs):
#         """raise on error"""
#         value_type = type(value)

#         if value_type in (list, deque, tuple, set):
#             value = value_type(StateDict._unpack_check_value(v, **kwargs) for v in value)
#         elif isinstance(value, dict):
#             value = { k : StateDict._unpack_check_value(v, **kwargs)
#                       for k, v in value.items() if StateDict._check_key(k) }
#         elif isinstance(value, Path):
#             if (rel_path := kwargs.get('rel_path', None)) is not None:
#                 value = lib_path.abspath(value, rel_path)
#         elif not (value_type in (NoneType, int, float, bool, str, bytes, bytearray) \
#                   or isinstance(value, (np.ndarray, np.generic)) ):
#             raise ValueError(f'Type of value {value_type} is not allowed in StateDict.')

#         return value


#     @staticmethod
#     def _eq_value(a, b):
#         """
#         raise on error
#         """
#         a_type = type(a)
#         b_type = type(b)

#         if a_type in (NoneType, int, float, bool, str, bytes, bytearray):
#             return a_type == b_type and a==b

#         elif isinstance(a, Path):
#             return isinstance(b, Path) and a==b

#         elif isinstance(a, (np.ndarray, np.generic)):
#             return isinstance(b, (np.ndarray, np.generic)) and np.array_equal(a, b)

#         elif a_type == b_type:

#             if isinstance(a, dict):

#                 for (k1,v1), (k2,v2) in zip(a.items(), b.items(), strict=True):
#                     if not StateDict._eq_value(k1, k2) or \
#                        not StateDict._eq_value(v1, v2):
#                         return False

#             elif a_type in (list, deque, tuple, set):

#                 for v1, v2 in zip(a, b, strict=True):
#                     if not StateDict._eq_value(v1, v2):
#                         return False

#         else:
#             return False

#     @staticmethod
#     def _check_key(key):
#         if type(key) in (int, float, str, bool):
#             return True
#         raise ValueError('Key must be a type of (int, float, str, bool)')
