from __future__ import annotations

from enum import Enum, auto
from typing import Self, Sequence, Tuple, TYPE_CHECKING, Type, overload

import numpy as np
import torch
import torch.nn.functional as F
from ..math import FAffMat2, FRectf, FVec2i

from ..torch import Device, get_cpu_device
from ..torch import functional as xF

if TYPE_CHECKING:
    from .FImage import FImage

class TImage:
    """
    Represents an Image of torch.tensor CHW image f32 only
    Provides image processing methods.

    """
    __slots__ = ['_img_t']
    
    _FImage_cls : Type[FImage] = ...
    
    class Interp(Enum):
        NEAREST = auto()
        LINEAR = auto()
        CUBIC = auto()

    class Border(Enum):
        CONSTANT = auto()
        REFLECT = auto()
        REPLICATE = auto()
    
    @staticmethod
    def ones(C,H,W, device : Device|None = None) -> FImage:
        """ones of f32 (C,H,W)"""
        if C not in (1,3,4):
            raise ValueError(f'img.C must be 1,3,4 but {C} provided.')

        self = TImage.__new__(TImage)
        self._img_t = torch.ones( (1,C,H,W), dtype=torch.float32, device=(device or get_cpu_device()).device)
        return self


    @staticmethod
    def ones_like(img : TImage) -> TImage:
        """ones of f32 of img's shape"""
        self = TImage.__new__(TImage)
        self._img_t = torch.ones_like(img._img_t)
        return self
    
    @staticmethod 
    def from_numpy(img : np.ndarray, channels_last : bool = True, device : Device|None = None) -> TImage:
        """```
            img     np.ndarray

            dtype must be uint8[0..255] (auto converted) or float32[0..1]

            acceptable format:
            HW[C] channels_last(True)
            [C]HW channels_last(False)

            C must be
                0: assume 1 ch
                1: assume grayscale
                3: assume BGR   (opencv & qt compliant)
                4: assume BGRA  (opencv & qt compliant)
        ```"""
        if (shape_len := len(img.shape)) == 2:
            H,W = img.shape
            C = 1
        elif shape_len == 3:
            if channels_last:
                H,W,C = img.shape
            else:
                C,H,W = img.shape
        else:
            raise ValueError(f'Wrong shape len {shape_len}')
        if C not in (1,3,4):
            raise ValueError(f'img.C must be 0,1,3,4 but {C} provided.')
        
        dtype = img.dtype
        
        img_t = torch.tensor(img).to( (device or get_cpu_device()).device, non_blocking=True)
        img_t = img_t.type(torch.float32, non_blocking=True)
        
        if dtype == np.uint8:
            img_t /= 255.0
            
        if channels_last:
            img_t = img_t.permute(2,0,1)
            
        r = TImage.__new__(TImage)
        r._img_t = img_t[None,...]
        return r
    
    @staticmethod
    def from_tensor(img_t : torch.Tensor) -> TImage:
        """img_t    1,C,H,W """
        N,C,H,W = img_t.shape
        if C not in (1,3,4):
            raise ValueError(f'img.C must be 1,3,4 but {C} provided.')
        
        r = TImage.__new__(TImage)
        r._img_t = img_t
        return r
            
    def __init__(self):
        self._img_t : torch.Tensor
        raise Exception('to create TImage use .from_ methods')
    
    @property
    def width(self) -> int: return self._img_t.shape[-1]
    @property
    def height(self) -> int: return self._img_t.shape[-2]

    @property
    def shape(self) -> Tuple[int, int, int]:
        """get (C,H,W) dims"""
        return self._img_t.shape[1:]
    @property
    def size(self) -> FVec2i:
        """ (W,H) as FVec2i"""
        return FVec2i(self.width, self.height)
    @property
    def dtype(self) -> torch.dtype:
        """torch.uint8 / torch.float32"""
        return self._img_t.dtype
    @property
    def device(self) -> Device:  return Device.from_device(self._img_t.device)
    
    def cpu(self) -> FImage:
        return TImage._FImage_cls.from_numpy(self._img_t[0].permute(1,2,0).cpu().numpy())
    
    def clone(self) -> Self:
        new_self = (c := self.__class__).__new__(c)
        new_self._img_t = self._img_t
        return new_self
    
    def copy(self) -> Self:
        self = self.clone()
        self._img_t = self._img_t.copy()
        return self
    
    def clip(self, min : float|None = None, max : float|None = None) -> Self:
        """clip to min,max.

        if min&max not specified , clips to 0..1
        """
        img_t = self._img_t
        if min is None and max is None:
            min = 0.0
            max = 1.0
        self = self.clone()
        self._img_t = img_t.clip(min, max)
        return self
    
    def ch(self, ch : int) -> Self:
        """
            same as call ch1()/bgr()/bgra()
            ch should be 1/3/4
        """
        if ch == 1:
            return self.ch1()
        elif ch == 3:
            return self.bgr()
        elif ch == 4:
            return self.bgra()
        raise ValueError('ch must be 1/3/4')
    
    def ch1(self) -> Self:
        """reduce to single ch"""
        C = (img_t := self._img_t).shape[1]
        if C == 1:
            return self
        self = self.clone()
        self._img_t = (img_t[:,:3,:,:].permute(0,2,3,1) @ torch.tensor([0.1140, 0.5870, 0.299], dtype=torch.float32).to(img_t.device, non_blocking=True))[:,None,:,:]
        return self
        
    def bgr(self) -> Self:
        """"""
        C = (img_t := self._img_t).shape[1]
        if C == 3:
            return self
        if C == 1:
            img_t = torch.tile(img_t, [1,3,1,1])
        if C == 4:
            img_t = img_t[:,:3,:,:]
        
        self = self.clone()
        self._img_t = img_t
        return self
    
    def bgra(self) -> Self:
        """"""
        C = (img_t := self._img_t).shape[1]
        if C == 4:
            return self
        
        if C == 1:
            img_t = torch.tile(img_t, [1,3,1,1])
            C = 3
        if C == 3:
            img_t = F.pad(img_t, (0,0,0,0, 0,1), mode='constant', value=1.0 )
        
        self = self.clone()
        self._img_t = img_t
        return self
    
    def blend(self, other : TImage, mask : TImage, alpha = 1.0) -> Self:
        """
        Pixel-wise blending `self*(1-mask*alpha) + other*mask*alpha`

            alpha  [0.0 ... 1.0]
        """
        img_t = _jit_blend(self._img_t, other._img_t, mask._img_t, alpha)      
       
        self = self.clone()
        self._img_t = img_t
        return self
    
    
    def channel_exposure(self, exposure : Sequence[float]) -> Self:
        """```
        Exposure applied per every channel.

            channel_exposure    (C,) float from - to +. 0 is no change

        ```"""
        _,C,_,_ = (img_t := self._img_t).shape

        if C != len(exposure):
            raise Exception('exposure must match C dims')
        
        img_t = img_t.clone()
   
        img_t *= 2**torch.tensor(exposure, dtype=torch.float32).to(img_t.device, non_blocking=True)[None,:,None,None]
        img_t.clip(0, 1)
        
        self = self.clone()
        self._img_t = img_t
        return self
    
    
    def invert(self) -> Self:
        img_t = self._img_t
        self = self.clone()
        self._img_t = 1.0 - img_t
        return self
    
    


    def box_sharpen(self, kernel_size : int, power : float) -> Self:
        """
         kernel_size   int     kernel size

         power  float   0 .. 1.0 (or higher)
        """
        power = max(0, power)
        if power == 0:
            return self
        
        img_t = self._img_t
        
        self = self.clone()
        img_t = xF.box_sharpen(img_t, kernel_size, power)
        img_t.clip_(0, 1)
        self._img_t = img_t
        return self
    
    def gaussian_blur(self, sigma : float) -> Self:
        """
        Spatial gaussian blur.

            sigma  float
        """
        sigma = max(0, sigma)
        if sigma == 0:
            return self

        img_t = self._img_t
        
        self = self.clone()
        self._img_t = xF.gaussian_blur(img_t, sigma)
        return self
    
    def gaussian_sharpen(self, sigma : float, power : float) -> Self:
        """
         sigma  float

         power  float   0 .. 1.0 and higher

        """
        sigma = max(0, sigma)
        if sigma == 0:
            return self
        img_t = self._img_t
        img_t = img_t*(1.0+power) + xF.gaussian_blur(img_t, sigma) * (-power)
        img_t.clamp_(0, 1)
        
        self = self.clone()
        self._img_t = img_t
        return self
    
    def hsv_shift(self, h_offset : float, s_offset : float, v_offset : float) -> Self:
        """```
            H,S,V in [-1.0..1.0]
        ```"""
        _,C,H,W = (img_t := self._img_t).shape
        if C != 3:
            raise Exception('C must be == 3')
        
        img_t = _jit_hsv_shift(img_t, h_offset, s_offset, v_offset)
        
        # cmax, cmax_idx = torch.max(img_t, dim=1, keepdim=True)
        # cmin = torch.min(img_t, dim=1, keepdim=True)[0]
        # delta = cmax - cmin
        # hsv_h = torch.empty_like(img_t[:, 0:1, :, :])
        # cmax_idx[delta == 0] = 3
        
        # cmax_idx_0 = cmax_idx == 2
        # cmax_idx_1 = cmax_idx == 1
        # cmax_idx_2 = cmax_idx == 0
        
        # hsv_h[cmax_idx_0] = (((img_t[:, 1:2] - img_t[:, 0:1]) / delta) % 6)[cmax_idx_0]
        # hsv_h[cmax_idx_1] = (((img_t[:, 0:1] - img_t[:, 2:3]) / delta) + 2)[cmax_idx_1]
        # hsv_h[cmax_idx_2] = (((img_t[:, 2:3] - img_t[:, 1:2]) / delta) + 4)[cmax_idx_2]
        # hsv_h[cmax_idx == 3] = 0.
        # hsv_h /= 6.
        # hsv_s = torch.where(cmax == 0, 0, delta / cmax) 
        # hsv_v = cmax
        
        # hsv_h = (hsv_h + h_offset) % 1
        # hsv_s = torch.clamp(hsv_s + s_offset, 0, 1);
        # hsv_v = torch.clamp(hsv_v + v_offset, 0, 1);
        
        # #import code
        # #code.interact(local=dict(globals(), **locals()))
        
        # _c = hsv_v * hsv_s
        # _x = _c * (1 - torch.abs(hsv_h * 6. % 2. - 1) )
        # _m = hsv_v - _c
        # _o = torch.zeros_like(_c)
        # idx = (hsv_h * 6.).type(torch.uint8)
        # idx = (idx % 6).expand(-1, 3, -1, -1)
        # rgb = torch.empty_like(img_t)
        # idx_0 = idx == 0
        # idx_1 = idx == 1
        # idx_2 = idx == 2
        # idx_3 = idx == 3
        # idx_4 = idx == 4
        # idx_5 = idx == 5
        # rgb[idx_0] = torch.cat([ _o, _x, _c, ], dim=1)[idx_0]
        # rgb[idx_1] = torch.cat([ _o, _c, _x, ], dim=1)[idx_1]
        # rgb[idx_2] = torch.cat([ _x, _c, _o, ], dim=1)[idx_2]
        # rgb[idx_3] = torch.cat([ _c, _x, _o, ], dim=1)[idx_3]
        # rgb[idx_4] = torch.cat([ _c, _o, _x, ], dim=1)[idx_4]
        # rgb[idx_5] = torch.cat([ _x, _o, _c, ], dim=1)[idx_5]
        # rgb += _m
        
        # img_t = rgb
        
   
        self = self.clone()
        self._img_t = img_t
        return self
    
    
    def h_flip(self) -> Self:
        img_t = self._img_t
        self = self.clone()
        self._img_t = torch.flip(img_t, [-1])
        return self
    def v_flip(self) -> Self:
        img_t = self._img_t
        self = self.clone()
        self._img_t = torch.flip(img_t, [-2])
        return self
    
    def levels(self, in_b, in_w, in_g, out_b, out_w) -> Self:
        """```
            in_b
            in_w
            in_g
            out_b
            out_w     (1,) or (C,) float

        ```"""
        _,C,H,W = (img_t := self._img_t).shape

        device = img_t.device
        in_b = torch.tensor(in_b, dtype=torch.float32).to(device, non_blocking=True)[None,:,None,None]
        in_w = torch.tensor(in_w, dtype=torch.float32).to(device, non_blocking=True)[None,:,None,None]
        in_g = torch.tensor(in_g, dtype=torch.float32).to(device, non_blocking=True)[None,:,None,None]
        out_b = torch.tensor(out_b, dtype=torch.float32).to(device, non_blocking=True)[None,:,None,None]
        out_w = torch.tensor(out_w, dtype=torch.float32).to(device, non_blocking=True)[None,:,None,None]
        img_t = _jit_levels(img_t, in_b, in_w, in_g, out_b, out_w)
   
        self = self.clone()
        self._img_t = img_t
        return self
    
    def motion_blur( self, kernel_size : int, angle : float):
        """
            kernel_size    >= 1

            angle   degrees
        """
        img_t = self._img_t
        
        self = self.clone()
        self._img_t = xF.motion_blur(img_t, kernel_size, angle)
        
        return self
    
    def swap_rb(self) -> Self:
        C = (img_t := self._img_t).shape[1]
        if C == 3:
            img_t = img_t[:, [2,1,0], :, :]
        if C == 1:
            return self
        if C == 4:
            img_t = img_t[:, [2,1,0,3], :, :]
        
        self = self.clone()
        self._img_t = img_t
        return self
    
    def pad(self, PADL : int = 0, PADT : int = None, PADR : int = None, PADB : int = None) -> Self:
        """```
        pad with zeros
        ```"""
        if PADT is None:
            PADT = PADL
        if PADR is None:
            PADR = PADT
        if PADB is None:
            PADB = PADR
        img_t = self._img_t
        
        self = self.clone()
        self._img_t = F.pad(img_t, (PADL, PADR, PADT,PADB) )
        return self
    
    def pad_to_next_divisor(self, dw : int|None = None, dh : int|None = None) -> Self:
        """
        pad image to next divisor of width/height

         dw,dh  int
        """
        _,H,W = self.shape

        w_pad = 0
        if dw is not None:
            w_pad = W % dw
            if w_pad != 0:
                w_pad = dw - w_pad

        h_pad = 0
        if dh is not None:
            h_pad = H % dh
            if h_pad != 0:
                h_pad = dh - h_pad

        if w_pad != 0 or h_pad != 0:
            return self.pad(0, 0, w_pad, h_pad)
        return self
    
    def resize(self, OW : int, OH : int, interp : Interp = Interp.LINEAR, smooth=False) -> Self:
        """resize to (OW,OH)"""
        _,C,H,W = (img_t := self._img_t).shape

        if smooth:
            while W != OW or H != OH:
                W = min(W*2.0, OW) if W < OW else max(OW, W/2.0)
                H = min(H*2.0, OH) if H < OH else max(OH, H/2.0)
                self = self.resize(int(W), int(H), interp=interp)

            return self

        if OW != W or OH != H:
            img_t = F.interpolate(img_t, (OH,OW), mode=_torch_interp[interp], align_corners=False  )
            
            self = self.clone()
            self._img_t = img_t
            return self
        return self
    
    def remap(self, grid_t : torch.Tensor, interp : Interp = Interp.LINEAR, border : Border = Border.CONSTANT) -> Self:
        """```
            grid_t    Tensor [H,W,2] float32 coords
        ```"""
        new_self = self.clone()
        new_self._img_t = xF.remap(self._img_t, grid_t[None,...], mode=_torch_interp[interp], padding_mode=_torch_border[border] )
        return new_self
    
    @overload
    def warp_affine(self, mat : FAffMat2, size : FVec2i, interp : Interp = Interp.LINEAR, border : Border = Border.CONSTANT) -> Self:
        """"""
    @overload
    def warp_affine(self, mat : FAffMat2, OW : int, OH : int, interp : Interp = Interp.LINEAR, border : Border = Border.CONSTANT) -> Self:
        """"""
    def warp_affine(self, *args, **kwargs) -> Self:
        mat = kwargs.get('mat', ...)
        size = kwargs.get('size', ...)
        OW = kwargs.get('OW', ...)
        OH = kwargs.get('OH', ...)
        interp = kwargs.get('interp', TImage.Interp.LINEAR)
        border = kwargs.get('border', TImage.Border.CONSTANT)
        
        args_len = len(args)
        if args_len >= 1:
            mat = args[0]
        if args_len >= 2:
            arg1 = args[1]
            if isinstance(arg1, FVec2i):
                size = arg1
                
                if args_len >= 3:
                    interp = args[2]
                if args_len >= 4:
                    border = args[3]
            else:
                OW = arg1
                
                if args_len >= 3:
                    OH = args[2]
                    
                if args_len >= 4:
                    interp = args[3]
                if args_len >= 5:
                    border = args[4]
        
        if not (size is Ellipsis):
            OW, OH = size
        
        img_t = self._img_t
        
        self = self.clone()
        self._img_t = xF.warp_affine(img_t, mat.as_np(), OW, OH, mode=_torch_interp[interp], padding_mode=_torch_border[border] )
        return self
    
    def __add__(self, value) -> Self:
        if isinstance(value, TImage):
            value = value._img_t
        img_t = self._img_t
        self = self.clone()
        self._img_t = img_t + value
        return self

    def __radd__(self, value) -> Self:
        if isinstance(value, TImage):
            value = value._img_t
        img_t = self._img_t
        self = self.clone()
        self._img_t = value + img_t
        return self

    def __sub__(self, value) -> Self:
        if isinstance(value, TImage):
            value = value._img_t
        img_t = self._img_t
        self = self.clone()
        self._img_t = img_t - value
        return self

    def __rsub__(self, value) -> Self:
        if isinstance(value, TImage):
            value = value._img_t
        img_t = self._img_t
        self = self.clone()
        self._img_t = value - img_t
        return self
    
    def __mul__(self, value) -> Self:
        if isinstance(value, TImage):
            value = value._img_t
        img_t = self._img_t
        self = self.clone()
        self._img_t = img_t * value
        return self

    def __rmul__(self, value) -> Self:
        if isinstance(value, TImage):
            value = value._img_t
        img_t = self._img_t
        self = self.clone()
        self._img_t = value * img_t
        return self

    def __truediv__(self, value) -> Self:
        if isinstance(value, TImage):
            value = value._img_t
        img_t = self._img_t
        self = self.clone()
        self._img_t = img_t / value
        return self

    def __rtruediv__(self, value) -> Self:
        if isinstance(value, TImage):
            value = value._i_img_tmg
        img_t = self._img_t
        self = self.clone()
        self._img_t = value / img_t
        return self
    
    def __iadd__(self, value) -> Self: raise Exception('in-place operation with FImage is not allowed')
    def __isub__(self, value) -> Self: raise Exception('in-place operation with FImage is not allowed')
    def __imul__(self, value) -> Self: raise Exception('in-place operation with FImage is not allowed')
    def __idiv__(self, value) -> Self: raise Exception('in-place operation with FImage is not allowed')
    def __itruediv__(self, value) -> Self: raise Exception('in-place operation with FImage is not allowed')


    
    def __repr__(self): return self.__str__()
    def __str__(self): return f'TImage {self._img_t.shape} {self._img_t.dtype}'

    
_torch_interp = {   TImage.Interp.NEAREST : 'nearest',
                    TImage.Interp.LINEAR : 'bilinear',
                    TImage.Interp.CUBIC : 'bicubic', }

_torch_border = {TImage.Border.CONSTANT : 'zeros',
                 TImage.Border.REFLECT : 'reflection',
                 TImage.Border.REPLICATE : 'border', }


@torch.jit.script
def _jit_blend(img : torch.Tensor, other : torch.Tensor, mask : torch.Tensor, alpha : float = 1.0):
    m = mask*alpha
    x = img* ( 1-m ) + other * m
    x = x.clip(0,1)
    return x

@torch.jit.script
def _jit_levels(img_t : torch.Tensor, in_b : torch.Tensor, in_w : torch.Tensor, in_g : torch.Tensor, out_b : torch.Tensor, out_w : torch.Tensor):
    img_t = torch.clip( (img_t - in_b) / (in_w-in_b), 0, 1)
    img_t = torch.pow(img_t, 1.0 / in_g) * (out_w - out_b) + out_b
    img_t = torch.clip(img_t, 0, 1)
    return img_t
        


@torch.jit.script
def _jit_hsv_shift(img_t : torch.Tensor, h_offset : float, s_offset : float, v_offset : float):
    cmax, cmax_idx = torch.max(img_t, dim=1, keepdim=True)
    cmin = torch.min(img_t, dim=1, keepdim=True)[0]
    delta = cmax - cmin
    hsv_h = torch.empty_like(img_t[:, 0:1, :, :])
    cmax_idx[delta == 0] = 3
    
    cmax_idx_0 = cmax_idx == 2
    cmax_idx_1 = cmax_idx == 1
    cmax_idx_2 = cmax_idx == 0
    
    hsv_h[cmax_idx_0] = (((img_t[:, 1:2] - img_t[:, 0:1]) / delta) % 6)[cmax_idx_0]
    hsv_h[cmax_idx_1] = (((img_t[:, 0:1] - img_t[:, 2:3]) / delta) + 2)[cmax_idx_1]
    hsv_h[cmax_idx_2] = (((img_t[:, 2:3] - img_t[:, 1:2]) / delta) + 4)[cmax_idx_2]
    hsv_h[cmax_idx == 3] = 0.
    hsv_h /= 6.
    hsv_s = torch.where(cmax == 0, 0, delta / cmax) 
    hsv_v = cmax
    
    hsv_h = (hsv_h + h_offset) % 1
    hsv_s = torch.clamp(hsv_s + s_offset, 0, 1);
    hsv_v = torch.clamp(hsv_v + v_offset, 0, 1);
    
    _c = hsv_v * hsv_s
    _x = _c * (1 - torch.abs(hsv_h * 6. % 2. - 1) )
    _m = hsv_v - _c
    _o = torch.zeros_like(_c)
    idx = (hsv_h * 6.).type(torch.uint8)
    idx = (idx % 6).expand(-1, 3, -1, -1)
    idx_0 = idx == 0
    idx_1 = idx == 1
    idx_2 = idx == 2
    idx_3 = idx == 3
    idx_4 = idx == 4
    idx_5 = idx == 5
    rgb = torch.empty_like(img_t)
    rgb[idx_0] = torch.cat([ _o, _x, _c, ], dim=1)[idx_0]
    rgb[idx_1] = torch.cat([ _o, _c, _x, ], dim=1)[idx_1]
    rgb[idx_2] = torch.cat([ _x, _c, _o, ], dim=1)[idx_2]
    rgb[idx_3] = torch.cat([ _c, _x, _o, ], dim=1)[idx_3]
    rgb[idx_4] = torch.cat([ _c, _o, _x, ], dim=1)[idx_4]
    rgb[idx_5] = torch.cat([ _x, _o, _c, ], dim=1)[idx_5]
    rgb += _m
    
    return rgb