from __future__ import annotations

from enum import Enum, auto
from numbers import Number
from typing import Self, Sequence, Tuple

import cv2
import numpy as np

from ..collections import FDict, get_enum_id_by_name
from ..image import FImage
from ..math import FAffMat2, FVec2f


class FLandmarks3DType(Enum):
    L2V = auto()
    L68 = auto()

class FLandmarks3D:
    """Immutable class. Describes 3D face landmarks"""

    Type = FLandmarks3DType

    @staticmethod
    def from_state(state : FDict|None) -> FLandmarks3D|None:
        state = FDict(state)
        if (type := get_enum_id_by_name(FLandmarks3DType, state.get('type', None), None)) is not None and \
           (lmrks := state.get('lmrks', None)) is not None:
            return FLandmarks3D(type, lmrks)
        return None


    def __init__(self, type : FLandmarks3DType, lmrks : Sequence[ Tuple[Number, Number] |
                                                                  Tuple[Number, Number, Number]
                                                                 ]):
        """
            lmrks np.ndarray  (*,2|3)
        """
        lmrks = np.array(lmrks, np.float32)

        N = lmrks.shape[0]
        if type == FLandmarks3DType.L2V:
            if N != 2: raise ValueError('lmrks count must be == 2')
        elif type == FLandmarks3DType.L5:
            if N != 5: raise ValueError('lmrks count must be == 5')
        elif type == FLandmarks3DType.L68:
            if N != 68: raise ValueError('lmrks count must be == 68')
        elif type == FLandmarks3DType.L106:
            if N != 106: raise ValueError('lmrks count must be == 106')
        elif type == FLandmarks3DType.L468:
            if N != 468: raise ValueError('lmrks count must be == 468')

        self._type  = type
        self._lmrks = lmrks

    @property
    def type(self) -> FLandmarks3DType: return self._type
    @property
    def count(self) -> int: return self._lmrks.shape[0]
    
    @property
    def projection(self):
        """to transform 3d pts to 2d image"""

    def clone(self) -> Self:
        f = self.__class__.__new__(self.__class__)
        f._type = self._type
        f._lmrks = self._lmrks
        return f

    def get_state(self) -> FDict:
        return FDict({  'type' : self._type.name,
                        'lmrks' : self._lmrks.tolist(),})

    def to(self, type : FLandmarks3DType) -> Self|None:
        """
        returns None if unable to convert.
        raise NO errors
        """
        if type == self.type:
            return self
        elif type == FLandmarks3DType.L68:
            if self.type == FLandmarks3DType.L106:
                lmrks = self._lmrks[ lmrks_106_to_68_mean_pairs ]
                return FLandmarks3D(type, lmrks.reshape( (68,2,2)).mean(1) )
            elif self.type == FLandmarks3DType.L98:
                lmrks = self._lmrks[ lmrks_98_to_68_mean_pairs ]
                return FLandmarks3D(type, lmrks.reshape( (68,2,2)).mean(1) )
        elif type == FLandmarks3DType.L68_chin:
            if (lmrks := self.to(FLandmarks3DType.L68)) is not None:
                return FLandmarks3D(FLandmarks3DType.L68_chin, lmrks.as_np()[0:17])

        return None

    def get_align_mat(self, exclude_moving_parts : bool = False) -> FAffMat2:
        """
        Calculates Affine2D to translate landmarks space to uniform 0..1 space

        raise on error
        """
        type = self._type

        # estimate landmarks transform from global space to local aligned space with bounds [0..1]
        if type == FLandmarks3DType.L2V:
            mat = FAffMat2.estimate(self._lmrks, uni_landmarks_L2V)
        elif type in [FLandmarks3DType.L106, FLandmarks3DType.L98, FLandmarks3DType.L68]:
            lmrks = self.to(FLandmarks3DType.L68)._lmrks

            #mat = FAffMat2.estimate( np.concatenate ([ lmrks[17:49], lmrks[54:55] ]), uni_landmarks_68)

            # Base align using all landmarks. Has right rotation, but moving parts of the face seriously affect scale of align.
            b_mat = FAffMat2.estimate(lmrks, uni_landmarks_68)

            # Align that excludes highly moving parts, such as chin, mouth, but side faces can be rotated more than normal.
            mat = FAffMat2.estimate( np.concatenate ([ lmrks[17:36], lmrks[36:37], lmrks[39:40], lmrks[42:43], lmrks[45:46], lmrks[48:49], lmrks[54:55] ]),
                                np.concatenate ([ uni_landmarks_68[17:36], uni_landmarks_68[36:37], uni_landmarks_68[39:40], uni_landmarks_68[42:43], uni_landmarks_68[45:46], uni_landmarks_68[48:49], uni_landmarks_68[54:55] ]), )

            # Get diff rotation between both alignments in global space
            a_v0, a_v1 = (mat * FAffMat2().translate(-0.5,-0.5)).inverted.map([FVec2f(0,0), FVec2f(1,0)])
            b_v0, b_v1 = (b_mat * FAffMat2().translate(-0.5,-0.5)).inverted.map([FVec2f(0,0), FVec2f(1,0)])

            angle_diff = (a_v1 - a_v0).angle(b_v1 - b_v0)

            # Rotate final align at the center
            mat = mat * FAffMat2().translate(-0.5,-0.5).rotate(-angle_diff).translate(0.5,0.5)

        elif type == FLandmarks3DType.L468:
            src_lmrks = self._lmrks
            dst_lmrks = uni_landmarks_468
            if exclude_moving_parts:
                src_lmrks = np.delete(src_lmrks, landmarks_468_moving_parts_indexes, 0)
                dst_lmrks = np.delete(dst_lmrks, landmarks_468_moving_parts_indexes, 0)

            mat = FAffMat2.estimate(src_lmrks, dst_lmrks)
        else:
            raise NotImplementedError()

        return mat

    def as_np(self) -> np.ndarray:
        """get landmarks as (N,2) np.ndarray"""
        return self._lmrks.copy()

    def transform(self, mat : FAffMat2) -> Self:
        """Tranforms FLandmarks3D using affine mat"""
        f = self.clone()
        f._lmrks = mat.map(f.as_np())
        return f

    def __repr__(self): return self.__str__()
    def __str__(self): return f'FLandmarks3D: {self._type}'

