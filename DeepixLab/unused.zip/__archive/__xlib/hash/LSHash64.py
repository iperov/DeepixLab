import numpy as np

class LSHash64(np.uint64):
    """Local-Sensitive 64-bit hash"""
        
    
        
        