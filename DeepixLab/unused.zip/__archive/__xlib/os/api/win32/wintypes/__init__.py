from .wintypes import (BOOL, DWORD, ERROR, GUID, HANDLE, HRESULT, IID,
                       LARGE_INTEGER, MMERROR, MMRESULT, REFGUID, REFIID,
                       IUnknown, dll_import, interface)
