"""
[S]heet-[S]ection-[I]tem.

Represents data structured in following classes:

Sheet -> List[Section]
              Section -> List[Item]
                              Item = Image | Audio | Text | ...
"""
from .ssi import Sheet, Section, Image